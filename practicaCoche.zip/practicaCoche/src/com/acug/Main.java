package com.acug;

class Coche{
    public int numerodepuertas = 4;

    public void sumarPuertas() {
        ++this.numerodepuertas;
    }
}